  <div>
  <center> 
 <div class="clr"></div> 
<!-- Google Analytics Code !-->  
 <a href="index.php"><img src="img/logo.png" style="width:100px;"/></a>  
 <div class="clr"></div>   
  <h2 class="aid-text">
  يقدم لكم موقعنا خدمة بطاقة المعايدة بمناسبة رمضان ، وكل عام وأنتم بالف خير ، يمكنك كتابة الإسم أسفله لإنشاء بطاقة خاصة بالإسم المدخل</h2>  
  <div class="clr"></div><br>      
  <form action="" method="post">
    <fieldset class="uk-fieldset">
        <div class="uk-margin">
            <input class="uk-input inpu" type="text" name="fullname" placeholder="أدخل الإسم هنا ">
        </div>
        <div class="uk-margin">
         <button type="submit" name="Send" class="uk-button button">عرض البطاقة </button>
        </div>    
    </fieldset>
  </form>
        <div class="clr"></div><br>  
        <!-- Google Adsense Code !-->
  </center>         
  </div> 